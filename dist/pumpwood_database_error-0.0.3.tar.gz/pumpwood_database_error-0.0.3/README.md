# pumpwood-postgres-error-treatment
Package with classes to treatment of postgres and SQLAlchemy associated errors.
