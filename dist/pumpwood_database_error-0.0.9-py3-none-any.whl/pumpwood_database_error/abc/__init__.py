"""Abstract Base Classes."""
from .general import ErrorTreatmentABC

__init__ = [
    ErrorTreatmentABC
]
