"""SQLAlchemy error treatment classes."""
from .general import TreatSQLAlchemyError


__init__ = [
    TreatSQLAlchemyError
]


__docformat__ = "google"
